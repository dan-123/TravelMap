//
//  PlaceCell.swift
//  TravelMap
//
//  Created by Даниил Петров on 06.07.2021.
//

import Foundation
import UIKit

// MARK: - Пока не используется

//final class PlaceCell: UITableViewCell {
//
//    static let indentifirer = "PlaceCell"
//
//    // добавить аргументы
//    func configure(country: String) {
//        textLabel?.numberOfLines = 0
//        textLabel?.text = country
//    }
//
//}
