//
//  Country+CoreDataClass.swift
//  TravelMap
//
//  Created by Даниил Петров on 16.07.2021.
//
//

import Foundation
import CoreData

@objc(Country)
public class Country: NSManagedObject {

}
