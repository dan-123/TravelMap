//
//  City+CoreDataClass.swift
//  TravelMap
//
//  Created by Даниил Петров on 17.07.2021.
//
//

import Foundation
import CoreData

@objc(City)
public class City: NSManagedObject {

}
